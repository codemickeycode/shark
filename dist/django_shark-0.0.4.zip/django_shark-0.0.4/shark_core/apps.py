from django.apps import AppConfig


class DocsConfig(AppConfig):
    name = 'shark_core'
