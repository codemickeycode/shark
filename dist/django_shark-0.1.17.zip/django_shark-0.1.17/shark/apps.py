from django.apps import AppConfig


class SharkConfig(AppConfig):
    name = 'shark'
