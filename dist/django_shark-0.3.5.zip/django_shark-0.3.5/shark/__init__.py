default_app_config = 'shark.apps.SharkConfig'
