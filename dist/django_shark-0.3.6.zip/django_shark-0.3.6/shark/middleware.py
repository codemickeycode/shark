from django.http import HttpRequest


class Logging:
    def process_request(self, request):
        # request = HttpRequest()
        request.a = 1
        print(request.a)
        print ('Called', request.path)
        return None

    def process_response(self, request, response):
        print('Done', response)
        request.a += 1
        print(request.a)
        return response

